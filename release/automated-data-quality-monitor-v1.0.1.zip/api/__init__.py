"""Optional FastAPI backend package."""
