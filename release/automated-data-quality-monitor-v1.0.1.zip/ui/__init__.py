"""Enterprise dashboard UI helpers."""
