"""Enterprise Altair chart styling helpers."""

from __future__ import annotations

import altair as alt

from ui.theme import chart_palette


def apply_enterprise_chart_theme(chart, height=320):
    """Apply consistent enterprise chart styling."""

    colors = chart_palette()
    return (
        chart.properties(height=height)
        .configure_view(strokeWidth=0)
        .configure_axis(
            gridColor=colors["grid"],
            labelColor=colors["muted"],
            titleColor=colors["text"],
            labelFontSize=12,
            titleFontSize=12,
        )
        .configure_legend(
            orient="top",
            title=None,
            labelColor=colors["text"],
            labelFontSize=12,
        )
        .configure_title(
            color=colors["text"],
            fontSize=15,
            fontWeight="bold",
        )
    )


def severity_color_scale():
    """Return an Altair severity color scale."""

    colors = chart_palette()
    return alt.Scale(
        domain=["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "NONE", "UNKNOWN"],
        range=[
            "#7F1D1D",
            "#EA580C",
            colors["warning"],
            "#3B82F6",
            colors["accent"],
            "#94A3B8",
            "#64748B",
        ],
    )


def score_band_color_scale():
    """Return an Altair quality-score band color scale."""

    colors = chart_palette()
    return alt.Scale(
        domain=["Healthy", "Watch", "Needs attention"],
        range=[colors["success"], colors["warning"], colors["error"]],
    )
